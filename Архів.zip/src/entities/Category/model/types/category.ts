export interface Category {
    _id: string;
    title?: string;
    photo?: string;
    favorite?: boolean;
    horizontal?: boolean;
}