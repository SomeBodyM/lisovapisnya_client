export interface Collection {
    _id?: string,
    title?: string,
    photo?: string,
    category?: string
}