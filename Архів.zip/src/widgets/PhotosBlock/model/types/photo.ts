export interface Photo {
    title?: string
}