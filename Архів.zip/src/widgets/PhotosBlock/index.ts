export {PhotosBlockList} from 'widgets/PhotosBlock/ui/PhotosBlockList/PhotosBlockList';
