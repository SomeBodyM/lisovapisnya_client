export interface CreatePhotoSchema {
    isLoading?: boolean;
    error?: string;
}