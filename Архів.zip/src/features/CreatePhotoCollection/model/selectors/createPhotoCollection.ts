import {StateSchema} from "app/providers/StoreProvider";

export const createPhotoCollectionIsLoading = (state: StateSchema) => state.createCollectionSchema?.isLoading;