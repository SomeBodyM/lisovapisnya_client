import ErrorBoundary from './ui/ErrorBoundary'

export { ErrorBoundary }
