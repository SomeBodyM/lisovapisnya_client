import {lazy} from "react";

export const PortfolioPageAsync = lazy(async () => await import('./PortfolioPage'))
