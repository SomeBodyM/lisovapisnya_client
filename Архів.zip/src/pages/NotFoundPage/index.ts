import { NotFoundPage } from 'pages/NotFoundPage/ui/NotFoundPage'

export { NotFoundPage }
