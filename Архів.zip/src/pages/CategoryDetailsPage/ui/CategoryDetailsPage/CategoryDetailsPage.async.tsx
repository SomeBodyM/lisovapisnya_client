import {lazy} from "react";

export const CategoryDetailsPageAsync = lazy(async () => await import('./CategoryDetailsPage'))